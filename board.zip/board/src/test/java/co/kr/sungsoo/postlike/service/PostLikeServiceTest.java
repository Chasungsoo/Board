package co.kr.sungsoo.postlike.service;

import co.kr.sungsoo.member.entity.Member;
import co.kr.sungsoo.member.enums.AccountType;
import co.kr.sungsoo.member.repository.MemberRepository;
import co.kr.sungsoo.post.entity.Post;
import co.kr.sungsoo.post.repository.PostRepository;
import co.kr.sungsoo.postlike.entity.PostLike;
import co.kr.sungsoo.postlike.repository.PostLikeRepository;
import co.kr.sungsoo.utils.Constants;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.transaction.annotation.Transactional;

import static org.assertj.core.api.Assertions.assertThat;


@SpringBootTest
@ExtendWith(SpringExtension.class)
class PostLikeServiceTest {

  @Autowired
  PostLikeService postLikeService;
  @Autowired
  PostLikeRepository postLikeRepository;
  @Autowired
  MemberRepository memberRepository;
  @Autowired
  PostRepository postRepository;

  Member member;
  Post post;
  @BeforeEach
  void setup(){
    Member insertMember = Member.builder()
        .accountId(Constants.ACCOUNT_ID)
        .nickname(Constants.NICKNAME)
        .accountType(AccountType.LESSEE)
        .build();

    member = memberRepository.save(insertMember);
    Post insetPost = Post.builder()
        .title(Constants.POST_TITLE)
        .contents(Constants.POST_CONTENTS)
        .member(member)
        .build();
    post = postRepository.save(insetPost);
  }
  @Test
  @DisplayName("이미 좋아요가 눌려있을경우(취소)")
  @Transactional
  void 좋아요_취소() throws Exception {

    PostLike like = PostLike.builder()
        .member(member)
        .post(post)
        .build();

    postLikeRepository.save(like);

    postLikeService.pushPostLikeButton(post.getId());

    assertThat(postLikeRepository.existPostLike(member.getId(),post.getId()).isPresent()).isFalse();
  }

  @Test
  @DisplayName("처음 좋아요를 눌렀을 경우(추가)")
  @Transactional
  void 좋아요_추가() throws Exception {

    postLikeService.pushPostLikeButton(post.getId());
    assertThat(postLikeRepository.existPostLike(member.getId(),post.getId()).isPresent()).isTrue();

  }
}