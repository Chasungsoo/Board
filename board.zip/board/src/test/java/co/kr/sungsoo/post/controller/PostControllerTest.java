package co.kr.sungsoo.post.controller;

import co.kr.sungsoo.post.dto.requset.PostRequsetDto;
import co.kr.sungsoo.post.service.PostService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;

import static co.kr.sungsoo.utils.Constants.*;
import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)
@SpringBootTest
@AutoConfigureMockMvc
class PostControllerTest {

  @Autowired
  MockMvc mockMvc;

  @Autowired
  PostService postService;

  PostRequsetDto postRequsetDto;

  @Autowired
  ObjectMapper objectMapper;

  @BeforeEach
  void setup() {
    postRequsetDto = PostRequsetDto.builder()
        .title(POST_TITLE)
        .contents(POST_CONTENTS)
        .build();
  }


  @Test
  public void 외부사용자_게시글_리스트_조회() throws Exception {
    mockMvc.perform(get("/api/post"))
        .andDo(print())
        .andExpect(status().isOk());
  }

  @Test
  public void 외부사용자_게시글_조회() throws Exception {
    mockMvc.perform(get("/api/post/detail/1"))
        .andDo(print())
        .andExpect(status().is4xxClientError());
  }

  @Test
  public void 외부사용자_게시글_쓰기() throws Exception {

    mockMvc.perform(post("/api/post/write"))
        .andDo(print())
        .andExpect(status().is4xxClientError());
  }

  @Test
  public void 외부사용자_게시글_수정() throws Exception {
    mockMvc.perform(put("/api/post/modify/1"))
        .andDo(print())
        .andExpect(status().is4xxClientError());
  }

  @Test
  public void 외부사용자_게시글_삭제() throws Exception {

    mockMvc.perform(put("/api/post/delete/1"))
        .andDo(print())
        .andExpect(status().is4xxClientError());
  }

}