package co.kr.sungsoo.comment.service;

import co.kr.sungsoo.comment.dto.requset.CommentDeleteDto;
import co.kr.sungsoo.comment.dto.requset.CommentRequestDto;
import co.kr.sungsoo.comment.entity.Comment;
import co.kr.sungsoo.comment.repository.CommentRepository;
import co.kr.sungsoo.member.entity.Member;
import co.kr.sungsoo.member.enums.AccountType;
import co.kr.sungsoo.member.repository.MemberRepository;
import co.kr.sungsoo.post.entity.Post;
import co.kr.sungsoo.post.repository.PostRepository;
import co.kr.sungsoo.utils.Constants;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.transaction.annotation.Transactional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.verify;


@SpringBootTest
@ExtendWith(SpringExtension.class)
class CommentServiceTest {

  @Autowired
  CommentService commentService;
  @Autowired
  PostRepository postRepository;
  @Autowired
  CommentRepository commentRepository;
  @Autowired
  MemberRepository memberRepository;

  Post post;
  Member member;
  CommentRequestDto commentRequestDto;

  @BeforeEach
  void setup() {

    member = Member.builder()
        .accountType(AccountType.LESSEE)
        .accountId(Constants.MEMBER_ID)
        .nickname(Constants.NICKNAME).build();
    memberRepository.save(member);

    post = Post.builder()
        .title(Constants.POST_TITLE)
        .contents(Constants.POST_CONTENTS)
        .member(member)
        .build();

    postRepository.save(post);

    commentRequestDto = CommentRequestDto.builder()
        .contents(Constants.COMMENT_CONTENTS)
        .memberId(member.getId())
        .build();
    commentRequestDto.setPostId(post.getId());

  }

  @Test
  @DisplayName("댓글 작성")
  @Transactional
  void 댓글_작성() throws Exception {

    Comment comment = commentRequestDto.toEntity(post, member.getId());
    Comment testComment = commentService.writeComment(commentRequestDto);
    assertThat(comment.getContents()).isEqualTo(testComment.getContents());
    assertThat(comment.getMemberId()).isEqualTo(testComment.getMemberId());

  }

  @Test
  @DisplayName("댓글 수정")
  @Transactional
  void 댓글_수정() throws Exception {

    Comment savedComment = commentService.writeComment(commentRequestDto);
    commentRequestDto.setCommentId(savedComment.getId());
    commentRequestDto.setContents("change");
    commentService.modifyComment(commentRequestDto);
    assertThat(savedComment.getContents()).isEqualTo("change");

  }

  @Test
  @DisplayName("댓글 삭제")
  @Transactional
  void 댓글_삭제() throws Exception {

    Comment savedComment = commentService.writeComment(commentRequestDto);
    CommentDeleteDto deleteDto = CommentDeleteDto.builder()
        .commentId(savedComment.getId())
        .memberId(savedComment.getMemberId()).build();
    commentRequestDto.setCommentId(savedComment.getId());
    commentService.deleteComment(deleteDto);
    assertThat(savedComment.getDelYn()).isEqualTo(Constants.DELETE_Y);

  }

}