package co.kr.sungsoo.post.service;

import co.kr.sungsoo.comment.service.CommentService;
import co.kr.sungsoo.member.entity.Member;
import co.kr.sungsoo.member.enums.AccountType;
import co.kr.sungsoo.member.repository.MemberRepository;
import co.kr.sungsoo.post.dto.requset.PostDeleteDto;
import co.kr.sungsoo.post.dto.requset.PostListDto;
import co.kr.sungsoo.post.dto.requset.PostRequsetDto;
import co.kr.sungsoo.post.dto.response.PostListResponseDto;
import co.kr.sungsoo.post.dto.response.PostResponseDto;
import co.kr.sungsoo.post.entity.Post;
import co.kr.sungsoo.post.repository.PostRepository;
import co.kr.sungsoo.utils.Constants;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@ExtendWith(SpringExtension.class)
class PostServiceTest {

  @Autowired
  PostRepository postRepository;
  @Autowired
  PostService postService;
  @Autowired
  MemberRepository memberRepository;
  @Autowired
  CommentService commentService;

  Member member;
  PostRequsetDto postRequsetDto;

  @BeforeEach
  void setup() {

    member = Member.builder()
        .accountType(AccountType.LESSEE)
        .accountId(Constants.MEMBER_ID)
        .nickname(Constants.NICKNAME).build();
    memberRepository.save(member);


    postRequsetDto = PostRequsetDto.builder()
        .memberId(member.getId())
        .title(Constants.POST_TITLE)
        .contents(Constants.POST_CONTENTS)
        .build();

  }

  @Test
  @DisplayName("게시글 리스트 조회")
  @Transactional
  void 게시글_리스트_조회() throws Exception {
    Post post = postRequsetDto.toEntity(member);
    postRepository.save(post);

    PostListDto listDto = PostListDto.builder()
        .memberId(member.getId())
        .memberYn(Constants.MEMBER_Y)
        .build();

    List<PostListResponseDto> postList = postService.getPostList(listDto);

    assertThat(postList.size()).isEqualTo(1);

  }

  @Test
  @DisplayName("게시글 상세조회")
  @Transactional
  void 게시글_상세_조회() throws Exception {

    Post post = postRequsetDto.toEntity(member);
    Post savedPost = postRepository.save(post);

    PostResponseDto postDetail = postService.getPostDetail(savedPost.getId());

    assertThat(postDetail.getContents()).isEqualTo(post.getContents());

  }

  @Test
  @DisplayName("게시글 작성")
  @Transactional
  void 게시글_작성() throws Exception {

    Post post = postService.writePost(postRequsetDto);
    assertThat(postRequsetDto.getContents()).isEqualTo(post.getContents());

  }

  @Test
  @DisplayName("게시글 수정")
  @Transactional
  void 게시글_수정() throws Exception {

    Post post = postService.writePost(postRequsetDto);
    postRequsetDto.setContents("수정된 내용");
    postRequsetDto.setPostId(post.getId());
    postService.modifyPost(postRequsetDto);

    assertThat(post.getContents()).isEqualTo("수정된 내용");

  }

  @Test
  @DisplayName("게시글 삭제")
  @Transactional
  void 게시글_삭제() throws Exception {

    Post post = postService.writePost(postRequsetDto);
    PostDeleteDto deleteDto = PostDeleteDto.builder()
        .memberId(member.getId())
        .postId(post.getId())
        .build();
    postService.deletePost(deleteDto);
    assertThat(post.getDelYn()).isEqualTo(Constants.DELETE_Y);

  }

}