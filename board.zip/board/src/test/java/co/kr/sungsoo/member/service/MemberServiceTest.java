package co.kr.sungsoo.member.service;

import co.kr.sungsoo.member.dto.request.MemberJoinRequestDto;
import co.kr.sungsoo.member.entity.Member;
import co.kr.sungsoo.member.enums.AccountType;
import co.kr.sungsoo.member.exception.MemberException;
import co.kr.sungsoo.member.exception.MemberExceptionEnum;
import co.kr.sungsoo.member.repository.MemberRepository;
import co.kr.sungsoo.utils.Constants;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.transaction.annotation.Transactional;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@ExtendWith(SpringExtension.class)
class MemberServiceTest {

  @Autowired
  MemberRepository memberRepository;

  @Autowired
  MemberService memberService;

  MemberJoinRequestDto memberJoinRequestDto;

  @BeforeEach
  void setup() {

    memberJoinRequestDto = MemberJoinRequestDto.builder()
        .accountId(Constants.ACCOUNT_ID)
        .nickname(Constants.NICKNAME)
        .accountType(AccountType.LESSEE.getName())
        .build();

  }

  @Test
  @DisplayName("회원가입")
  @Transactional
  void 회원가입() throws Exception {

    Member member = memberService.createMember(memberJoinRequestDto);

    Member getJoinMember = memberRepository.findByAccountIdAndQuit(member.getAccountId(), Constants.DELETE_N)
        .orElseThrow(() -> new MemberException(MemberExceptionEnum.VALIDATION_NONMEMBER_EXCEPTION));

    assertThat(getJoinMember.getAccountId()).isEqualTo(memberJoinRequestDto.getAccountId());
    assertThat(getJoinMember.getNickname()).isEqualTo(memberJoinRequestDto.getNickname());
    assertThat(getJoinMember.getAccountType().getName()).isEqualTo(memberJoinRequestDto.getAccountType());

  }

  @Test
  @DisplayName("회원탈퇴")
  @Transactional
  void 회원탈퇴() throws Exception {

    Member insertMember = memberJoinRequestDto.toEntity();
    Member savedMember = memberRepository.save(insertMember);

    Assertions.assertThat(Constants.DELETE_N).isEqualTo(savedMember.getQuit());

    memberService.quitMember(savedMember.getId());

    Member quitMember = memberRepository.findByIdAndQuit(savedMember.getId(), Constants.DELETE_Y)
        .orElseThrow(() -> new MemberException(MemberExceptionEnum.VALIDATION_NONMEMBER_EXCEPTION));
    Assertions.assertThat(Constants.DELETE_Y).isEqualTo(quitMember.getQuit());
  }
}