package co.kr.sungsoo.member.controller;

import co.kr.sungsoo.member.dto.request.MemberJoinRequestDto;
import co.kr.sungsoo.member.entity.Member;
import co.kr.sungsoo.member.enums.AccountType;
import co.kr.sungsoo.member.repository.MemberRepository;
import co.kr.sungsoo.member.service.MemberService;
import co.kr.sungsoo.utils.Constants;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)
@SpringBootTest
@AutoConfigureMockMvc
class MemberControllerTest {

  @Autowired
  MockMvc mockMvc;
  @Autowired
  MemberRepository memberRepository;
  @Autowired
  MemberService memberService;
  @Autowired
  ObjectMapper objectMapper;


  MemberJoinRequestDto memberDto;

  @BeforeEach
  void setup() {
    memberDto = MemberJoinRequestDto.builder()
        .accountId(Constants.ACCOUNT_ID)
        .nickname(Constants.NICKNAME)
        .accountType(AccountType.LESSEE.getName())
        .build();
  }

  @Test
  @DisplayName("외부사용자회원가입")
  public void 외부사용자_회원가입() throws Exception {


    String content = objectMapper.writeValueAsString(memberDto);
    mockMvc.perform(post("/api/member")
            .content(content)
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON))
        .andDo(print())
        .andExpect(status().isOk());
  }

  @Test
  @DisplayName("외부사용자회원탈퇴")
  public void 외부사용자_회원탈퇴() throws Exception {


    Member member = memberDto.toEntity();

    mockMvc.perform(put("/api/member/" + member.getId())
            .accept(MediaType.APPLICATION_JSON))
        .andDo(print())
        .andExpect(status().is4xxClientError());
  }

  @Test
  @DisplayName("내부사용자회원탈퇴")
  public void 내부사용자_회원탈퇴() throws Exception {


    Member member = memberDto.toEntity();

    Member savedMember = memberRepository.save(member);

    mockMvc.perform(put("/api/member/" + member.getId())
            .accept(MediaType.APPLICATION_JSON)
            .header(Constants.AUTHORIZATION_HEADER, savedMember.getAccountType().getType() + " " + savedMember.getId()))
        .andDo(print())
        .andExpect(status().isOk());
  }
}