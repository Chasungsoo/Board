package co.kr.sungsoo.comment.controller;

import co.kr.sungsoo.comment.dto.requset.CommentRequestDto;
import co.kr.sungsoo.comment.service.CommentService;
import co.kr.sungsoo.utils.Constants;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.user;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)
@SpringBootTest
@AutoConfigureMockMvc
class CommentControllerTest {

  @Autowired
  MockMvc mockMvc;

  @Autowired
  CommentService commentService;

  @Autowired
  ObjectMapper objectMapper;

  CommentRequestDto commentRequestDto;

  @BeforeEach
  void setup() {
    commentRequestDto = CommentRequestDto.builder()
        .contents(Constants.COMMENT_CONTENTS)
        .memberId(1l)
        .build();
  }

  @Test
  public void 외부사용자_댓글_쓰기() throws Exception {

    String content = objectMapper.writeValueAsString(commentRequestDto);

    mockMvc.perform(post("/api/comment/1").content(content)
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON))
        .andDo(print())
        .andExpect(status().is4xxClientError());
  }

  @Test
  public void 외부사용자_댓글_수정() throws Exception {

    String content = objectMapper.writeValueAsString(commentRequestDto);

    mockMvc.perform(put("/api/comment/modify/1").content(content)
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON))
        .andDo(print())
        .andExpect(status().is4xxClientError());
  }

  @Test
  public void 외부사용자_댓글_삭제() throws Exception {

    mockMvc.perform(put("/api/comment/delete/1")
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON))
        .andDo(print())
        .andExpect(status().is4xxClientError());
  }

}