package co.kr.sungsoo.member.exception;

import lombok.Getter;

@Getter
public class MemberException extends RuntimeException {

  private MemberExceptionEnum error;

  public MemberException(MemberExceptionEnum e) {
    super(e.getMessage());
    this.error = e;
  }
}
