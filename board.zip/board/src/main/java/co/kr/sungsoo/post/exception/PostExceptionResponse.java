package co.kr.sungsoo.post.exception;

import lombok.Builder;
import lombok.Getter;

@Getter
public class PostExceptionResponse {

  private String errorCode;
  private String errorMessage;

  @Builder
  public PostExceptionResponse(String errorCode, String errorMessage) {
    this.errorCode = errorCode;
    this.errorMessage = errorMessage;
  }
}
