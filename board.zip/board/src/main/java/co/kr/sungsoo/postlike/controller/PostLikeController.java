package co.kr.sungsoo.postlike.controller;

import co.kr.sungsoo.postlike.service.PostLikeService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/postlike")
public class PostLikeController {

  private final PostLikeService postLikeService;

  @PostMapping("/{id}")
  public ResponseEntity<Boolean> pushLikeButton(@PathVariable("id") Long postId){
    return ResponseEntity.ok(postLikeService.pushPostLikeButton(postId));
  }
}
