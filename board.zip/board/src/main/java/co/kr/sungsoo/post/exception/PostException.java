package co.kr.sungsoo.post.exception;

import lombok.Getter;

@Getter
public class PostException extends RuntimeException {

  private PostExceptionEnum error;

  public PostException(PostExceptionEnum e) {
    super(e.getMessage());
    this.error = e;
  }
}