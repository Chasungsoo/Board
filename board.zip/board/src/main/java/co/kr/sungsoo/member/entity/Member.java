package co.kr.sungsoo.member.entity;

import co.kr.sungsoo.common.BaseTimeEntity;
import co.kr.sungsoo.member.enums.AccountType;
import co.kr.sungsoo.post.entity.Post;
import co.kr.sungsoo.utils.Constants;
import lombok.*;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Getter
@ToString
@NoArgsConstructor(access = AccessLevel.PROTECTED)
public class Member extends BaseTimeEntity {

  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  @Column(name = "MEMBER_ID")
  private Long id;

  private String nickname;

  private String accountId;

  private String quit;

  @Enumerated(EnumType.STRING)
  private AccountType accountType;

  @OneToMany(mappedBy = "member", cascade = CascadeType.ALL)
  private List<Post> posts = new ArrayList<>();

  @Builder
  public Member(String nickname, String accountId, AccountType accountType) {
    this.nickname = nickname;
    this.accountId = accountId;
    this.accountType = accountType;
    this.quit = Constants.DELETE_N;
  }

  public void addPost(Post post) {
    this.posts.add(post);
    post.updateMember(this);
  }

  public void deleteMember(String quit) {
    this.quit = quit;
  }

}
