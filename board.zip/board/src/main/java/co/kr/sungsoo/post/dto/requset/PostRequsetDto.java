package co.kr.sungsoo.post.dto.requset;

import co.kr.sungsoo.member.entity.Member;
import co.kr.sungsoo.post.entity.Post;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.NotBlank;

@Getter
@Setter
@NoArgsConstructor
public class PostRequsetDto {

  @NotBlank(message = "글 제목을 입력해 주세요")
  private String title;

  @NotBlank(message = "글 내용을 입력해 주세요")
  private String contents;

  private Long memberId;

  private Long postId;

  @Builder
  public PostRequsetDto(String title, String contents, Long memberId) {
    this.title = title;
    this.contents = contents;
    this.memberId = memberId;
  }

  public Post toEntity(Member member){

    Post post = Post.builder()
        .title(title)
        .contents(contents)
        .member(member)
        .build();

    member.addPost(post);

    return post;
  }
}
