package co.kr.sungsoo.comment.exception;

import lombok.Getter;

@Getter
public class CommentException extends RuntimeException {

  private CommentExceptionEnum error;

  public CommentException(CommentExceptionEnum e) {
    super(e.getMessage());
    this.error = e;
  }
}
