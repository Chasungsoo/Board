package co.kr.sungsoo.post.service;

import co.kr.sungsoo.comment.entity.Comment;
import co.kr.sungsoo.member.entity.Member;
import co.kr.sungsoo.member.repository.MemberRepository;
import co.kr.sungsoo.post.dto.requset.PostDeleteDto;
import co.kr.sungsoo.post.dto.requset.PostListDto;
import co.kr.sungsoo.post.dto.requset.PostRequsetDto;
import co.kr.sungsoo.post.dto.response.PostCommentResponseDto;
import co.kr.sungsoo.post.dto.response.PostListResponseDto;
import co.kr.sungsoo.post.dto.response.PostResponseDto;
import co.kr.sungsoo.post.entity.Post;
import co.kr.sungsoo.post.exception.PostException;
import co.kr.sungsoo.post.exception.PostExceptionEnum;
import co.kr.sungsoo.post.repository.PostRepository;
import co.kr.sungsoo.postlike.repository.PostLikeRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

import static co.kr.sungsoo.utils.Constants.*;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class PostService {

  private final PostRepository postRepository;
  private final PostLikeRepository postLikeRepository;
  private final MemberRepository memberRepository;

  public List<PostListResponseDto> getPostList(PostListDto listDto) {
    return postRepository.findAllByDelYn(DELETE_N)
        .stream()
        .map(post -> PostListResponseDto.builder()
            .title(post.getTitle())
            .writer(post.getWriter(post.getMember()))
            .postId(post.getId())
            .postLikeCount(postLikesCount(post.getId()))
            .pushedLikeButton(listDto.getMemberYn().equals(MEMBER_Y) ?
                checkPushedLikeButton(listDto.getMemberId(), post.getId()) :
                false)
            .build())
        .collect(Collectors.toList());
  }

  public PostResponseDto getPostDetail(Long id) {
    Post post = getSelected(id);

    List<Comment> comments = post.getComments();
    List<PostCommentResponseDto> commentList = comments.stream().map(comment -> {
      return PostCommentResponseDto.builder()
          .contents(comment.getContents())
          .memberId(comment.getMemberId())
          .build();
    }).collect(Collectors.toList());


    return PostResponseDto.builder()
        .title(post.getTitle())
        .contents(post.getContents())
        .writer(post.getWriter(post.getMember()))
        .postId(post.getId())
        .postLikeCount(postLikesCount(post.getId()))
        .commentList(commentList)
        .build();
  }

  @Transactional
  public Post writePost(PostRequsetDto postRequsetDto) {
    Member member = memberRepository.findByIdAndQuit(postRequsetDto.getMemberId(), DELETE_N)
        .orElseThrow(() -> new PostException(PostExceptionEnum.VALIDATION_NONMEMBER_EXCEPTION));
    Post post = postRequsetDto.toEntity(member);
    return postRepository.save(post);
  }

  @Transactional
  public void modifyPost(PostRequsetDto postRequsetDto) {
    Post post = getSelected(postRequsetDto.getPostId());
    post.checkPostWriter(post.getMember().getId(), postRequsetDto.getMemberId());
    post.updatePost(postRequsetDto.getTitle(), postRequsetDto.getContents());
  }


  @Transactional
  public void deletePost(PostDeleteDto postDeleteDto) {
    Post post = getSelected(postDeleteDto.getPostId());
    post.checkPostWriter(post.getMember().getId(), postDeleteDto.getMemberId());
    post.deletePost(DELETE_Y);
  }

  private Boolean checkPushedLikeButton(Long memberId, Long postId) {
    return postLikeRepository.existPostLike(memberId, postId)
        .isPresent();
  }

  private int postLikesCount(Long postId) {
    return postLikeRepository.findPostLikeNum(postId);
  }

  private Post getSelected(Long postDeleteDto) {
    return postRepository.findByIdAndDelYn(postDeleteDto, DELETE_N)
        .orElseThrow(() -> new PostException(PostExceptionEnum.VALIDATION_NON_POST_EXCEPTION));
  }

}
