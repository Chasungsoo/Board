package co.kr.sungsoo.member.controller;

import co.kr.sungsoo.member.dto.request.MemberJoinRequestDto;
import co.kr.sungsoo.member.entity.Member;
import co.kr.sungsoo.member.exception.MemberException;
import co.kr.sungsoo.member.exception.MemberExceptionEnum;
import co.kr.sungsoo.member.service.MemberService;
import co.kr.sungsoo.utils.Constants;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

@Controller
@RequestMapping("/api/member")
@RequiredArgsConstructor
public class MemberController {

  private final MemberService memberService;

  @PostMapping
  public ResponseEntity<String> joinMember(@Valid @RequestBody MemberJoinRequestDto memberJoinRequestDto) throws Exception {
    Member member = memberService.createMember(memberJoinRequestDto);
    return ResponseEntity.ok("회원가입을 축하합니다.회원님의 회원번호는 " + member.getId() + "입니다.");
  }

  @PutMapping("/{id}")
  public ResponseEntity<String> quitMember(@PathVariable("id") Long memberId, HttpServletRequest request) {
    if (request.getAttribute(Constants.NONMEMBER) != null) {
      throw new MemberException(MemberExceptionEnum.FORBIDDEN_EXCEPTION);
    }
    memberService.quitMember(memberId);
    return ResponseEntity.ok("회원님 정상적으로 탈퇴 되었습니다.");
  }

}
