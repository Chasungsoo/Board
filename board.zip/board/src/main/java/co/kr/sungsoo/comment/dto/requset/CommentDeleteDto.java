package co.kr.sungsoo.comment.dto.requset;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CommentDeleteDto {

  private Long memberId;

  private Long commentId;

  @Builder
  public CommentDeleteDto(Long memberId, Long commentId) {
    this.memberId = memberId;
    this.commentId = commentId;
  }
}
