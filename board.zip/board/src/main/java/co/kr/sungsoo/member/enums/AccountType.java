package co.kr.sungsoo.member.enums;

import co.kr.sungsoo.member.exception.MemberException;
import co.kr.sungsoo.member.exception.MemberExceptionEnum;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

import java.util.Collections;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@RequiredArgsConstructor
@Getter
public enum AccountType {

  ADMIN("Admin", "관리자"),
  MANAGER("Manager", "매니저"),
  MEMBER("Member", "회원"),
  없음(null,null);

  private final String type;
  private final String name;

  private static final Map<String, AccountType> values =
      Collections.unmodifiableMap(Stream.of(values())
          .collect(Collectors.toMap(AccountType::getType, Function.identity())));

  private static final Map<String, AccountType> names =
      Collections.unmodifiableMap(Stream.of(values())
          .collect(Collectors.toMap(AccountType::getName, Function.identity())));

  public static AccountType find(String value) {
    return Optional.ofNullable(values.get(value)).orElse(없음);
  }

  public static AccountType verifyCreateMemberAccountType(String name) {
    AccountType accountType = Optional.ofNullable(names.get(name)).orElse(없음);
    if (accountType == 없음){
      throw new MemberException(MemberExceptionEnum.VALIDATION_AUTHORIZATION_EXCEPTION);
    }
    return Optional.ofNullable(names.get(name)).orElse(없음);
  }
}
