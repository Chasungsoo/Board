package co.kr.sungsoo.member.dto.request;

import co.kr.sungsoo.member.entity.Member;
import co.kr.sungsoo.member.enums.AccountType;
import lombok.*;
import javax.validation.constraints.NotBlank;


@Getter
@ToString
@NoArgsConstructor
public class MemberJoinRequestDto {

  @NotBlank(message = "닉네임은 필수값 입니다.")
  private String nickname;

  @NotBlank(message = "계정아이디는 필수값 입니다.")
  private String accountId;

  @NotBlank(message = "관리자,매니저,회원 중 하나를 선택해 주세요.")
  private String accountType;

  @Builder
  public MemberJoinRequestDto(String nickname, String accountId, String accountType) {
    this.nickname = nickname;
    this.accountId = accountId;
    this.accountType = accountType;
  }

  public Member toEntity() throws Exception {
    return Member.builder()
        .accountId(accountId)
        .nickname(nickname)
        .accountType(AccountType.verifyCreateMemberAccountType(accountType))
        .build();
  }
}
