package co.kr.sungsoo.member.exception;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum MemberExceptionEnum {

  FORBIDDEN_EXCEPTION(ErrorStatusCode.FORBIDDEN_EXCEPTION, "해당 권한이 없습니다"),
  VALIDATION_NONMEMBER_EXCEPTION(ErrorStatusCode.VALIDATION_EXCEPTION, "회원 정보가 없습니다."),
  VALIDATION_AUTHORIZATION_EXCEPTION(ErrorStatusCode.VALIDATION_EXCEPTION, "계정타입은 입대인/회원/매니저 만 가능합니다."),
  VALIDATION_MEMBER_CONFLICT_EXCEPTION(ErrorStatusCode.CONFLICT_EXCEPTION, "회원정보가 이미 존재하고 있습니다.");


  private final ErrorStatusCode statusCode;
  private final String message;

  @Getter
  @RequiredArgsConstructor
  private enum ErrorStatusCode {
    VALIDATION_EXCEPTION(400, "VALIDATION_EXCEPTION"),
    FORBIDDEN_EXCEPTION(403, "FORBIDDEN_EXCEPTION"),
    CONFLICT_EXCEPTION(409, "CONFLICT_EXCEPTION");

    private final int statusCode;
    private final String code;
  }

  public int getStatusCode() {
    return this.statusCode.getStatusCode();
  }
  }