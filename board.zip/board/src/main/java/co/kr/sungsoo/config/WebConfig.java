package co.kr.sungsoo.config;

import co.kr.sungsoo.interceptor.AuthorizationInterceptor;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import java.util.Arrays;
import java.util.List;

@Configuration
@RequiredArgsConstructor
public class WebConfig implements WebMvcConfigurer {

  private static final List<String> EXCLUDE_URL_PATTERNS = Arrays.asList("/api/member","/api/post/detail/**");
  private final AuthorizationInterceptor authorizationInterceptor;

  @Override
  public void addInterceptors(InterceptorRegistry registry) {
    registry.addInterceptor(authorizationInterceptor)
        .addPathPatterns("/**")
        .excludePathPatterns(EXCLUDE_URL_PATTERNS);
  }
}
