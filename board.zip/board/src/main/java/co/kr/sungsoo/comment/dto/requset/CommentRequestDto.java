package co.kr.sungsoo.comment.dto.requset;

import co.kr.sungsoo.comment.entity.Comment;
import co.kr.sungsoo.post.entity.Post;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotBlank;

@Getter
@Setter
public class CommentRequestDto {

  @NotBlank(message = "댓글내용을 입력해 주세요.")
  private String contents;

  private Long commentId;

  private Long postId;

  private Long memberId;

  @Builder
  public CommentRequestDto(String contents, Long memberId) {

    this.contents = contents;
    this.memberId = memberId;

  }

  public Comment toEntity(Post post, Long writer) {

    Comment comment = Comment.builder()
        .post(post)
        .contents(contents)
        .memberId(writer)
        .build();
    post.addComments(comment);

    return comment;
  }
}
