package co.kr.sungsoo.post.controller;

import co.kr.sungsoo.post.dto.requset.PostDeleteDto;
import co.kr.sungsoo.post.dto.requset.PostListDto;
import co.kr.sungsoo.post.dto.requset.PostRequsetDto;
import co.kr.sungsoo.post.dto.response.PostListResponseDto;
import co.kr.sungsoo.post.dto.response.PostResponseDto;
import co.kr.sungsoo.post.exception.PostException;
import co.kr.sungsoo.post.exception.PostExceptionEnum;
import co.kr.sungsoo.post.service.PostService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.util.List;

import static co.kr.sungsoo.utils.Constants.*;


@RequiredArgsConstructor
@RestController
@RequestMapping("/api/post")
public class PostController {

  private final PostService postService;

  @GetMapping
  public ResponseEntity<List<PostListResponseDto>> list(HttpServletRequest request) {
    Object memberYn = request.getAttribute(NONMEMBER);
    PostListDto listDto = null;
    if (memberYn == null) {
      listDto = PostListDto.builder()
          .memberYn(MEMBER_Y)
          .memberId(Long.parseLong(String.valueOf(request.getAttribute(MEMBER_ID))))
          .build();
    } else {
      listDto = PostListDto.builder()
          .memberYn(MEMBER_N)
          .build();
    }

    return ResponseEntity.ok(postService.getPostList(listDto));
  }

  @GetMapping("/detail/{id}")
  public ResponseEntity<PostResponseDto> detail(@PathVariable("id") Long id) {
    return ResponseEntity.ok(postService.getPostDetail(id));
  }

  @PostMapping("/write")
  public ResponseEntity<String> write(@Valid @RequestBody PostRequsetDto postRequsetDto, HttpServletRequest request) throws Exception {
    postRequsetDto.setMemberId(getMemberId(request));
    postService.writePost(postRequsetDto);
    return ResponseEntity.ok("게시글을 등록했습니다.");
  }

  @PutMapping("/modify/{id}")
  public ResponseEntity<String> modifyPost(@Valid @RequestBody PostRequsetDto postRequsetDto,
                                           @PathVariable("id") Long postId,
                                           HttpServletRequest request) throws Exception {
    verifyNonMember(request);
    postRequsetDto.setMemberId(getMemberId(request));
    postRequsetDto.setPostId(postId);
    postService.modifyPost(postRequsetDto);
    return ResponseEntity.ok("게시글을 수정했습니다.");
  }

  private void verifyNonMember(HttpServletRequest request) {
    if (request.getAttribute(NONMEMBER) != null) {
      throw new PostException(PostExceptionEnum.FORBIDDEN_NOT_AUTHORIZATION_EXCEPTION);
    }
  }

  @PutMapping("/delete/{id}")
  public ResponseEntity<String> deletePost(@PathVariable("id") Long postId, HttpServletRequest request) {
    verifyNonMember(request);
    PostDeleteDto deleteDto = PostDeleteDto.builder()
        .postId(postId)
        .memberId(getMemberId(request))
        .build();
    postService.deletePost(deleteDto);
    return ResponseEntity.ok("게시글을 삭제했습니다.");
  }

  private long getMemberId(HttpServletRequest request) {
    long memberId = Long.parseLong(String.valueOf(request.getAttribute(MEMBER_ID)));
    return memberId;
  }
}
