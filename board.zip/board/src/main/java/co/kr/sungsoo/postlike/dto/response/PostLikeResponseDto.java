package co.kr.sungsoo.postlike.dto.response;

import lombok.Builder;
import lombok.Getter;

@Getter
public class PostLikeResponseDto {

  private Long count;
  private Boolean check;

  @Builder
  public PostLikeResponseDto(Long count, Boolean check){
    this.count = count;
    this.check = check;
  }
}
