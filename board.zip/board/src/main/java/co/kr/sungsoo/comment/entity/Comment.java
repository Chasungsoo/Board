package co.kr.sungsoo.comment.entity;

import co.kr.sungsoo.comment.dto.requset.CommentRequestDto;
import co.kr.sungsoo.comment.exception.CommentException;
import co.kr.sungsoo.comment.exception.CommentExceptionEnum;
import co.kr.sungsoo.common.BaseTimeEntity;
import co.kr.sungsoo.post.entity.Post;
import co.kr.sungsoo.utils.Constants;
import lombok.*;

import javax.persistence.*;

@Entity
@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
public class Comment extends BaseTimeEntity {

  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  @Column(name = "COMMENT_ID")
  private Long id;

  private String contents;

  private String delYn;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "POST_ID")
  private Post post;

  private Long memberId;

  public void updatePost(Post post) {
    this.post = post;
  }

  @Builder
  public Comment(String contents, Post post, Long memberId) {
    this.contents = contents;
    this.post = post;
    this.memberId = memberId;
    this.delYn = Constants.DELETE_N;
  }

  public void deleteComment(String deleteY) {
    this.delYn = deleteY;
  }

  public void checkCommentWriter(Long commentMemberId, Long currentMemberId) {
    if (commentMemberId != currentMemberId) {
      throw new CommentException(CommentExceptionEnum.FORBIDDEN_EXCEPTION);
    }
  }

  public void updateComment(CommentRequestDto commentRequestDto) {
    this.contents = commentRequestDto.getContents();
  }
}
