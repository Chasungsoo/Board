package co.kr.sungsoo.postlike.dto.request;

import lombok.Builder;
import lombok.Getter;

@Getter
public class PostLikeRequsetDto {

  private String accountId;

  private Long postId;

  @Builder
  public PostLikeRequsetDto(String accountId, Long postId) {
    this.accountId = accountId;
    this.postId = postId;
  }

}
