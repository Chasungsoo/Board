package co.kr.sungsoo.post.exception;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Getter
public enum PostExceptionEnum {

  VALIDATION_NONMEMBER_EXCEPTION(ErrorStatusCode.VALIDATION_EXCEPTION, "회원정보가 없습니다."),
  FORBIDDEN_NOT_AUTHORIZATION_EXCEPTION(ErrorStatusCode.FORBIDDEN_EXCEPTION, "해당 게시글 수정 삭제 권한이 없습니다."),
  VALIDATION_NON_POST_EXCEPTION(ErrorStatusCode.VALIDATION_EXCEPTION, "해당 게시글이 없습니다.");

  private final ErrorStatusCode statusCode;
  private final String message;

  @Getter
  @RequiredArgsConstructor
  private enum ErrorStatusCode {
    VALIDATION_EXCEPTION(400, "VALIDATION_EXCEPTION"),
    FORBIDDEN_EXCEPTION(403, "FORBIDDEN_EXCEPTION");

    private final int statusCode;
    private final String code;
  }

  public int getStatusCode() {
    return this.statusCode.getStatusCode();
  }
}
