package co.kr.sungsoo.postlike.service;

import co.kr.sungsoo.post.entity.Post;
import co.kr.sungsoo.post.exception.PostException;
import co.kr.sungsoo.post.exception.PostExceptionEnum;
import co.kr.sungsoo.post.repository.PostRepository;
import co.kr.sungsoo.postlike.entity.PostLike;
import co.kr.sungsoo.postlike.repository.PostLikeRepository;
import co.kr.sungsoo.utils.Constants;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


@Service
@Transactional(readOnly = true)
@RequiredArgsConstructor
public class PostLikeService {

  private final PostLikeRepository postLikeRepository;
  private final PostRepository postRepository;

  @Transactional
  public Boolean pushPostLikeButton(Long postId) {

    Post post = postRepository.findByIdAndDelYn(postId, Constants.DELETE_N)
        .orElseThrow(() -> new PostException(PostExceptionEnum.VALIDATION_NON_POST_EXCEPTION));

    PostLike postLike = postLikeRepository.existPostLike(post.getMember().getId(), postId).orElse(null);
    if (postLike != null) {
      postLikeRepository.deleteById(postLike.getId());
    } else {
      postLike = getPostLike(post);
      postLikeRepository.save(postLike);
    }

    return true;
  }

  private PostLike getPostLike(Post post) {
    PostLike like = PostLike.builder()
        .member(post.getMember())
        .post(post)
        .build();
    return like;
  }
}
