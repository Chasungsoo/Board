package co.kr.sungsoo.comment.controller;

import co.kr.sungsoo.comment.dto.requset.CommentDeleteDto;
import co.kr.sungsoo.comment.dto.requset.CommentRequestDto;
import co.kr.sungsoo.comment.service.CommentService;
import co.kr.sungsoo.post.exception.PostException;
import co.kr.sungsoo.post.exception.PostExceptionEnum;
import co.kr.sungsoo.utils.Constants;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/comment")
public class CommentController {

  private final CommentService commentService;

  @PostMapping("/{id}")
  public ResponseEntity<String> writeComment(@Valid @RequestBody CommentRequestDto commentRequestDto,
                                             @PathVariable("id") Long postId,
                                             HttpServletRequest request) {
    verifyNonMember(request);
    commentRequestDto.setMemberId(getMemberId(request));
    commentRequestDto.setPostId(postId);
    commentService.writeComment(commentRequestDto);
    return ResponseEntity.ok("댓글을 작성하였습니다.");
  }

  @PutMapping("/modify/{id}")
  public ResponseEntity<String> modifyComment(@Valid @RequestBody CommentRequestDto commentRequestDto,
                                              @PathVariable("id") Long commentId,
                                              HttpServletRequest request) {
    verifyNonMember(request);
    commentRequestDto.setCommentId(commentId);
    commentRequestDto.setMemberId(getMemberId(request));
    commentService.modifyComment(commentRequestDto);
    return ResponseEntity.ok("댓글을 수정하였습니다.");
  }

  private void verifyNonMember(HttpServletRequest request) {
    if (request.getAttribute(Constants.NONMEMBER) != null) {
      throw new PostException(PostExceptionEnum.FORBIDDEN_NOT_AUTHORIZATION_EXCEPTION);
    }
  }

  @PutMapping("/delete/{id}")
  public ResponseEntity<String> deleteComment(@PathVariable("id") Long commentId, HttpServletRequest request) {
    verifyNonMember(request);
    CommentDeleteDto deleteDto = CommentDeleteDto.builder()
        .commentId(commentId)
        .memberId(getMemberId(request))
        .build();
    commentService.deleteComment(deleteDto);
    return ResponseEntity.ok("댓글이 삭제되었습니다.");
  }

  private long getMemberId(HttpServletRequest request) {
    long memberId = Long.parseLong(String.valueOf(request.getAttribute(Constants.MEMBER_ID)));
    return memberId;
  }

}
