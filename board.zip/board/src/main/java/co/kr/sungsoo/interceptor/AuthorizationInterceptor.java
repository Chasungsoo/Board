package co.kr.sungsoo.interceptor;

import co.kr.sungsoo.member.entity.Member;
import co.kr.sungsoo.member.enums.AccountType;
import co.kr.sungsoo.member.exception.MemberException;
import co.kr.sungsoo.member.exception.MemberExceptionEnum;
import co.kr.sungsoo.member.repository.MemberRepository;
import co.kr.sungsoo.utils.Constants;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@Component
@RequiredArgsConstructor
public class AuthorizationInterceptor implements HandlerInterceptor {


  private final MemberRepository memberRepository;

  @Override
  public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {

    if (request.getHeader(Constants.AUTHORIZATION_HEADER) != null) {

      try {
        String authorization = request.getHeader(Constants.AUTHORIZATION_HEADER);
        String[] roleAndMemberIdArray = authorization.split(" ");
        String role = roleAndMemberIdArray[0];
        Long memberId = Long.parseLong(roleAndMemberIdArray[1]);

        AccountType accountType = AccountType.find(role);

        if (accountType == AccountType.없음) {
          throw new MemberException(MemberExceptionEnum.FORBIDDEN_EXCEPTION);
        }

        Member member = memberRepository.findByIdAndQuit(memberId, Constants.DELETE_N)
            .orElseThrow(() -> new MemberException(MemberExceptionEnum.FORBIDDEN_EXCEPTION));
        request.setAttribute(Constants.MEMBER_ID, member.getId());
      } catch (Exception e) {
        throw new MemberException(MemberExceptionEnum.FORBIDDEN_EXCEPTION);
      }

    } else {
      request.setAttribute(Constants.NONMEMBER,"Y");
    }
    return true;

  }
}
