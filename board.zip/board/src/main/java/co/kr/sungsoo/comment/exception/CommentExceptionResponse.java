package co.kr.sungsoo.comment.exception;

import lombok.Builder;
import lombok.Getter;

@Getter
public class CommentExceptionResponse {

  private String errorCode;
  private String errorMessage;

  @Builder
  public CommentExceptionResponse(String errorCode, String errorMessage) {
    this.errorCode = errorCode;
    this.errorMessage = errorMessage;
  }
}
