package co.kr.sungsoo.post.dto.response;


import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PostCommentResponseDto {

  private String contents;

  private String memberId;

  @Builder
  public PostCommentResponseDto(String contents, Long memberId){
    this.contents = contents;
    this.memberId = String.valueOf(memberId);

  }

}
