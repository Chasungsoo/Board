package co.kr.sungsoo.post.entity;

import co.kr.sungsoo.comment.entity.Comment;
import co.kr.sungsoo.common.BaseTimeEntity;
import co.kr.sungsoo.member.entity.Member;
import co.kr.sungsoo.post.exception.PostException;
import co.kr.sungsoo.post.exception.PostExceptionEnum;
import co.kr.sungsoo.postlike.entity.PostLike;
import lombok.*;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

import static co.kr.sungsoo.utils.Constants.DELETE_N;

@Entity
@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
public class Post extends BaseTimeEntity {

  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  @Column(name = "POST_ID")
  private Long id;

  private String title;

  private String contents;

  private String delYn;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "MEMBER_ID")
  private Member member;

  @OneToMany(mappedBy = "post", cascade = CascadeType.ALL)
  private List<Comment> comments = new ArrayList<>();

  @OneToMany(mappedBy = "post", cascade = CascadeType.ALL)
  private List<PostLike> postLikes = new ArrayList<>();

  @Builder
  public Post(String title, String contents, Member member) {
    this.title = title;
    this.contents = contents;
    this.member = member;
    this.delYn = DELETE_N;
  }

  @Builder
  public Post(String title, String contents, Member member, Long id) {
    this.title = title;
    this.contents = contents;
    this.member = member;
    this.delYn = DELETE_N;
    this.id = id;
  }

  public void updateMember(Member member) {
    this.member = member;
  }

  public void addComments(Comment comment) {
    this.comments.add(comment);
    comment.updatePost(this);
  }

  public void updatePost(String title, String contents) {
    this.title = title;
    this.contents = contents;
  }

  public void deletePost(String deleteY) {
    this.delYn = deleteY;
  }

  public void checkPostWriter(Long postAccountId, Long currentMemberId) {
    if (postAccountId != currentMemberId) {
      throw new PostException(PostExceptionEnum.FORBIDDEN_NOT_AUTHORIZATION_EXCEPTION);
    }
  }

  public String getWriter(Member member) {
    return member.getNickname() + "(" + member.getAccountType().getName() + ")";
  }
}
