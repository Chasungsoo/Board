package co.kr.sungsoo.member.service;

import co.kr.sungsoo.member.dto.request.MemberJoinRequestDto;
import co.kr.sungsoo.member.entity.Member;
import co.kr.sungsoo.member.exception.MemberException;
import co.kr.sungsoo.member.exception.MemberExceptionEnum;
import co.kr.sungsoo.member.repository.MemberRepository;
import co.kr.sungsoo.utils.Constants;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class MemberService {

  private final MemberRepository memberRepository;

  @Transactional
  public Member createMember(MemberJoinRequestDto dto) throws Exception {
    Member member = dto.toEntity();
    validateDuplicateMember(member);
    return memberRepository.save(member);

  }

  private void validateDuplicateMember(Member member) {
    if (memberRepository.findByAccountIdAndQuit(member.getAccountId(), Constants.DELETE_N).isPresent()) {
      throw new MemberException(MemberExceptionEnum.VALIDATION_MEMBER_CONFLICT_EXCEPTION);
    }
  }

  @Transactional
  public void quitMember(Long id) {
    Member member = memberRepository.findByIdAndQuit(id, Constants.DELETE_N)
        .orElseThrow(() -> new MemberException(MemberExceptionEnum.VALIDATION_NONMEMBER_EXCEPTION));
    member.deleteMember(Constants.DELETE_Y);
  }

}
