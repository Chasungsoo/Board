package co.kr.sungsoo.comment.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class CommentExceptionHandler {

  @ExceptionHandler(CommentException.class)
  public ResponseEntity<CommentExceptionResponse> exceptionHandler(CommentException e) {

    CommentExceptionResponse response = CommentExceptionResponse.builder()
        .errorCode(String.valueOf(e.getError().getStatusCode()))
        .errorMessage(e.getMessage())
        .build();

    return new ResponseEntity<>(response, HttpStatus.valueOf(e.getError().getStatusCode()));
  }
}
