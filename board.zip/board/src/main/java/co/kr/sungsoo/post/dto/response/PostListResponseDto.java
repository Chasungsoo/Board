package co.kr.sungsoo.post.dto.response;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class PostListResponseDto {

  private String title;

  private String writer;

  private Long postId;

  private int postLikeCount;

  private boolean pushedLikeButton;


  @Builder
  public PostListResponseDto(String title, String writer,
                         Long postId, int postLikeCount, boolean pushedLikeButton) {
    this.title = title;
    this.writer = writer;
    this.postId = postId;
    this.postLikeCount = postLikeCount;
    this.pushedLikeButton = pushedLikeButton;
  }
}
