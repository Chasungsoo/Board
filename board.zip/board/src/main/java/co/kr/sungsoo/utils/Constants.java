package co.kr.sungsoo.utils;

public class Constants {

  public static final String DELETE_Y = "Y";
  public static final String DELETE_N = "N";
  public static final String MEMBER_Y = "Y";
  public static final String MEMBER_N = "N";
  public static final String NONMEMBER = "nonMember";
  public static final String MEMBER_ID = "memberId";
  public static final String NICKNAME = "nickName";
  public static final String ACCOUNT_ID = "accountId";
  public static final String POST_TITLE = "postTitle";
  public static final String POST_CONTENTS = "postContents";
  public static final String COMMENT_CONTENTS = "commentContents";
  public static final String AUTHORIZATION_HEADER = "Authorization";
}
