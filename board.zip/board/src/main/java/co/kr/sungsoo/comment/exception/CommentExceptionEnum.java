package co.kr.sungsoo.comment.exception;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Getter
public enum CommentExceptionEnum {
  VALIDATION_NON_COMMENT_EXCEPTION(ErrorStatusCode.VALIDATION_EXCEPTION, "존재하지 않는 댓글입니다."),
  FORBIDDEN_EXCEPTION(ErrorStatusCode.FORBIDDEN_EXCEPTION, "댓글 수정 삭제 권한이 없습니다.");

  private final ErrorStatusCode statusCode;
  private final String message;

  @Getter
  @RequiredArgsConstructor
  private enum ErrorStatusCode {
    FORBIDDEN_EXCEPTION(403, "FORBIDDEN_EXCEPTION"),
    VALIDATION_EXCEPTION(400, "VALIDATION_EXCEPTION");

    private final int statusCode;
    private final String code;
  }

  public int getStatusCode() {
    return this.statusCode.getStatusCode();
  }
}
