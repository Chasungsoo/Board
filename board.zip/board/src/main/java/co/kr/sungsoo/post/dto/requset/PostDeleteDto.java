package co.kr.sungsoo.post.dto.requset;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PostDeleteDto {

  private Long memberId;

  private Long postId;

  @Builder
  public PostDeleteDto(Long memberId, Long postId) {
    this.memberId = memberId;
    this.postId = postId;
  }
}
