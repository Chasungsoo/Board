package co.kr.sungsoo.postlike.repository;

import co.kr.sungsoo.postlike.entity.PostLike;
import co.kr.sungsoo.postlike.entity.QPostLike;
import com.querydsl.jpa.impl.JPAQueryFactory;
import javax.persistence.EntityManager;
import java.util.Optional;

public class PostLikeRepositoryImpl implements PostLikeCustomRepository {

  private final JPAQueryFactory queryFactory;

  public PostLikeRepositoryImpl(EntityManager em) {
    this.queryFactory = new JPAQueryFactory(em);
  }

  public Optional<PostLike> existPostLike(Long memberId, Long postId) {
    PostLike pLike = queryFactory
        .selectFrom(QPostLike.postLike)
        .where(
            QPostLike.postLike.member.id.eq(memberId),
            QPostLike.postLike.post.id.eq(postId)
        ).fetchFirst();
    return Optional.ofNullable(pLike);
  }

  public int findPostLikeNum(Long postId) {
    return queryFactory
        .selectFrom(QPostLike.postLike)
        .where(QPostLike.postLike.post.id.eq(postId))
        .fetch().size();
  }
}
