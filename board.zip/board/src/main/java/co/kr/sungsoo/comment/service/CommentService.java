package co.kr.sungsoo.comment.service;

import co.kr.sungsoo.comment.dto.requset.CommentDeleteDto;
import co.kr.sungsoo.comment.dto.requset.CommentRequestDto;
import co.kr.sungsoo.comment.entity.Comment;
import co.kr.sungsoo.comment.exception.CommentException;
import co.kr.sungsoo.comment.exception.CommentExceptionEnum;
import co.kr.sungsoo.comment.repository.CommentRepository;
import co.kr.sungsoo.post.entity.Post;
import co.kr.sungsoo.post.exception.PostException;
import co.kr.sungsoo.post.exception.PostExceptionEnum;
import co.kr.sungsoo.post.repository.PostRepository;
import co.kr.sungsoo.utils.Constants;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class CommentService {

  private final CommentRepository commentRepository;
  private final PostRepository postRepository;

  @Transactional
  public Comment writeComment(CommentRequestDto commentRequestDto) {
    Post post = postRepository.findByIdAndDelYn(commentRequestDto.getPostId(), Constants.DELETE_N)
        .orElseThrow(() -> new PostException(PostExceptionEnum.VALIDATION_NON_POST_EXCEPTION));
    Comment comment = commentRequestDto.toEntity(post, commentRequestDto.getMemberId());
    return commentRepository.save(comment);
  }

  @Transactional
  public void deleteComment(CommentDeleteDto commentDeleteDto) {
    Comment comment = getSelectedComment(commentDeleteDto.getCommentId());
    comment.checkCommentWriter(comment.getMemberId(), commentDeleteDto.getMemberId());
    comment.deleteComment(Constants.DELETE_Y);
  }

  @Transactional
  public void modifyComment(CommentRequestDto commentRequestDto) {
    Comment comment = getSelectedComment(commentRequestDto.getCommentId());
    comment.checkCommentWriter(comment.getMemberId(), commentRequestDto.getMemberId());
    comment.updateComment(commentRequestDto);
  }

  private Comment getSelectedComment(Long commentId) {
    return commentRepository.findByIdAndDelYn(commentId, Constants.DELETE_N)
        .orElseThrow(() -> new CommentException(CommentExceptionEnum.VALIDATION_NON_COMMENT_EXCEPTION));
  }
}
