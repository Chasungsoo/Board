package co.kr.sungsoo.postlike.entity;

import co.kr.sungsoo.member.entity.Member;
import co.kr.sungsoo.post.entity.Post;
import lombok.AccessLevel;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Entity
@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
public class PostLike {

  @Id @GeneratedValue(strategy = GenerationType.AUTO)
  @Column(name = "POSTLIKE_ID")
  private Long id;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "MEMBER_ID")
  private Member member;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "POST_ID")
  private Post post;

  @Builder
  public PostLike(Member member, Post post) {
    this.member = member;
    this.post = post;
  }
}
