package co.kr.sungsoo.member.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class MemberExceptionHandler {

  @ExceptionHandler(MemberException.class)
  public ResponseEntity<MemberExceptionResponse> exceptionHandler(MemberException e) {
    MemberExceptionResponse response = MemberExceptionResponse.builder()
        .errorCode(String.valueOf(e.getError().getStatusCode()))
        .errorMessage(e.getMessage())
        .build();
    return new ResponseEntity<>(response, HttpStatus.valueOf(e.getError().getStatusCode()));
  }

}
