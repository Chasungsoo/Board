package co.kr.sungsoo.post.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class PostExceptionHandler {

  @ExceptionHandler(PostException.class)
  public ResponseEntity<PostExceptionResponse> exceptionHandler(PostException e){

    PostExceptionResponse response = PostExceptionResponse.builder()
        .errorCode(String.valueOf(e.getError().getStatusCode()))
        .errorMessage(e.getMessage())
        .build();

    return new ResponseEntity<>(response, HttpStatus.valueOf(e.getError().getStatusCode()));
  }
}
