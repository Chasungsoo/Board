package co.kr.sungsoo.postlike.repository;

import co.kr.sungsoo.postlike.entity.PostLike;

import java.util.Optional;

public interface PostLikeCustomRepository {

  Optional<PostLike> existPostLike(Long memberId, Long postId);

  int findPostLikeNum(Long postId);
}
