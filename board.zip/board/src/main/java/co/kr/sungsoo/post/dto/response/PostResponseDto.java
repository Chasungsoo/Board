package co.kr.sungsoo.post.dto.response;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;


@Getter
@Setter
public class PostResponseDto {

  private String title;

  private String contents;

  private String writer;

  private Long postId;

  private int postLikeCount;

  private List<PostCommentResponseDto> commentList = new ArrayList<>();

  @Builder
  public PostResponseDto(String title, String contents, String writer,
                         Long postId, int postLikeCount, List<PostCommentResponseDto> commentList) {
    this.title = title;
    this.contents = contents;
    this.writer = writer;
    this.postId = postId;
    this.postLikeCount = postLikeCount;
    this.commentList = commentList;
  }

}
