package co.kr.sungsoo.post.dto.requset;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Builder
public class PostListDto {

  private String memberYn;

  private Long memberId;


}
