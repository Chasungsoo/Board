package co.kr.sungsoo.member.repository;

import co.kr.sungsoo.member.entity.Member;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface MemberRepository extends JpaRepository<Member, Long> {

  Optional<Member> findByAccountIdAndQuit(String accountId, String quit);

  Optional<Member> findByIdAndQuit(Long memberId, String quit);

}
