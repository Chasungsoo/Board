# 마이다스아이티 포트폴리오 제출용  By Chasungsoo


## 프로젝트 실행 방법
> ### 1. 깃허브에서 클론 받은 후 
> ### 2. gradle other -> compileQueryDsl 실행 
> ### 3. 서버 실행
> ### 4. http 패키지에서 테스트 가능



## 기능 사항

> ### 1. Java, Spring Boot 사용.
> - [x] Java 8로 구현
> - [x] Spring Boot 2.x 버전대 사용
> ### 2. 관리자,매니저,회원는 글,댓글 C.U.D 가능 , 외부사용자 불가능
> - [x] 인터셉터 권한인증으로 구현
> ### 3. 가입사용자에 의한 자신이 좋아요한 글인지 아닌지 표시.
> - [x] 자신이 누른 좋아요 체크기능 구현
> ### 4. 글 목록화면에 좋아요수 표시
> - [x] 글목록 불러올때 좋아요수 가져오기 구현


* * *

## 기술 요구사항

> ### 1.글 작성, 수정, 삭제, 목록
> - [x] 글 목록 엔드포인트 = http://localhost:8081/api/post, Method  = Get
> - [x] 글 상세 엔드포인트 = http://localhost:8081/api/post/detail/{postId}, Method  = Get
> - [x] 글 등록 엔드포인트 = http://localhost:8081/api/post/write, Method  = Post
> - [x] 글 수정 엔드포인트 = http://localhost:8081/api/post/modify/{postId}, Method  = Put
> - [x] 글 삭제 엔드포인트 = http://localhost:8081/api/post/delete/{postId}, Method  = Put
> ### 2.댓글 작성, 수정, 삭제
> - [x] 댓글 등록 엔드포인트 = http://localhost:8081/api/comment/{postId}, Method  = Post
> - [x] 댓글 수정 엔드포인트 = http://localhost:8081/api/comment/modyfy/{commentId}, Method  = Put
> - [x] 댓글 삭제 엔드포인트 = http://localhost:8081/api/comment/delete/{commentId}, Method  = Put
> ### 3.인증헤더값 prefix 사용하여 권한 구분 인증헤더값이 없다면 외부사용자.
> - [x] AuthorizationInterceptor 에서 권한 구분
> ### 4.관리자 매니저 회원인 경우 별도의 회원테이블을 만들어 사용합니다.
> - [x] 회원가입 엔드포인트 = http://localhost:8081/api/member, Method  = Post
> - [x] 회원탈퇴 엔드포인트 = http://localhost:8081/api/member/{memberId}, Method  = Put
> ### 5. 글 좋아요는 한계정이 한글에 한번만 할 수 있습니다..
> - [x] 좋아요 기능 엔드포인트 = http://localhost:8081/api/postlike/{postId}, Method  = Post
> ### 6. 어떤 사용자가 어떤 글에 좋아요 했는지 히스토리를 확인할 수 있어야 합니다.
> - [x] PostLike -> memberId,postId 컬럼으로 확인 가능
> ### 7. 각 글은 작성시간, 마지막 수정시간, 삭제시간에 대한 히스토리를 확인할 수 있어야 합니다..
> - [x] createDate, modifiyDate , delYn 컬럽으로 확인가능


## 구현방법

> ### 1.글 작성, 수정, 삭제, 목록
> - 목록조회를 제외한 기능에 대해선 인터셉터에서 권한을 검증 후 Controller에 진입되도록 구현
> ### 2.댓글 작성, 수정, 삭제
> - 모든 기능은 인터셉터에서 권한인증을 거친 후 진행 -> 수정 삭제와 같은 경우는 비지니스로직에서 내가쓸 댓글일 경우만 가능하도록 validationCheck 진행
> ### 3.인증헤더값 prefix 사용하여 권한 구분 인증헤더값이 없다면 외부사용자.
> - AuthorizationInterceptor에서 리퀘스트 헤더의 Authorization 값을 통하여 권한 구분
> ### 4.관리자 매니저 회원인 경우 별도의 회원테이블을 만들어 사용합니다.
> - 회원가입 기능을 추가해서 회원가입시 Member 테이블에 저장
> ### 5. 글 좋아요는 한계정이 한글에 한번만 할 수 있습니다.
> - 좋아요 클릭시 토글형식으로 한번만 가능
> ### 6. 어떤 사용자가 어떤 글에 좋아요 했는지 히스토리를 확인할 수 있어야 합니다.
> - 좋아요 클릭시 db 저장 (memberId postId 포함)
> ### 7. 각 글은 작성시간, 마지막 수정시간, 삭제시간에 대한 히스토리를 확인할 수 있어야 합니다.
> - 각 글과 댓글에 관하여 시간 히스토리 저장

